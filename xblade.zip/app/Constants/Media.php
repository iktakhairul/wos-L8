<?php

namespace App\Constants;

abstract class Media
{
    const DEFAULT = 'default';
    const USER_PROFILE_IMAGE = 'USER_PROFILE_IMAGE';
}
