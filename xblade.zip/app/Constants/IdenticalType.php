<?php

namespace App\Constants;

class IdenticalType
{
    const NID = 'NID';
    const PASSPORT = 'PASSPORT';
    const BIRTH_CERTIFICATE = 'BIRTH_CERTIFICATE';
    const DRIVING_LICENSE = 'DRIVING_LICENSE';
    const TIN = 'TIN';

}
