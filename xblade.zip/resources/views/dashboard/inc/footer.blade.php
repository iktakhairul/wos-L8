<footer class="container-fluid">
    <div class="row">
        <div class="col-12 text-center">
            {{ date('Y') }} &copy; Copyright <strong>{{ config('app.name') }}</strong> All Rights Reserved
        </div>
    </div>
</footer>